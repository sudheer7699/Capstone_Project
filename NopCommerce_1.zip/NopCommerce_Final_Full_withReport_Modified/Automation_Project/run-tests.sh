#!/bin/bash
mvn clean test -Dbrowser=chrome
